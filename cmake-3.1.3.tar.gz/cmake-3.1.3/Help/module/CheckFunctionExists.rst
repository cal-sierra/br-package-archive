.. cmake-module:: ../../Modules/CheckFunctionExists.cmake
