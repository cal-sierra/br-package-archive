avrdude
=======

avrdude with a Linux SPI programmer type

Kevin Cuzner Jun 2013
kevin@kevincuzner.com

Using baud-rate to control SPI frequency

Rui Azevedo (neu-rah) Jun 2013
ruihfazevedo[arroba]gmail.com
